def get_color_contrast(color: str) -> str:
    # TODO: Implement
    return color
