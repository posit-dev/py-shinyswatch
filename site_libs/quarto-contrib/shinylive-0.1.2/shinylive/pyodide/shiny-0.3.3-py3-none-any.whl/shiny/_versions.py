shiny_html_deps = "1.7.4"
bslib = "0.4.2.9000"
bootstrap = "5.2.2"
requirejs = "2.3.6"

__all__ = (
    "shiny_html_deps",
    "bslib",
    "bootstrap",
    "requirejs",
)
