shiny_html_deps = "1.8.0"
bslib = "0.6.1.9000"
htmltools = "0.5.7"
bootstrap = "5.3.1"
requirejs = "2.3.6"

__all__ = (
    "shiny_html_deps",
    "bslib",
    "htmltools",
    "bootstrap",
    "requirejs",
)
