from .index import anchors_plugin

__all__ = ("anchors_plugin",)
