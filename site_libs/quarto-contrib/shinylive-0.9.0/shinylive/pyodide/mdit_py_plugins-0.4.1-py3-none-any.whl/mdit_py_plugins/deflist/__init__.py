from .index import deflist_plugin

__all__ = ("deflist_plugin",)
