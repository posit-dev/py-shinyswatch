from .index import footnote_plugin

__all__ = ("footnote_plugin",)
