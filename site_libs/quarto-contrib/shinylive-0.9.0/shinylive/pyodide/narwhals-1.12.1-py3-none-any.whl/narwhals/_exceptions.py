from __future__ import annotations


class ColumnNotFoundError(Exception): ...
