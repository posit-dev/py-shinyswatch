This template gives you a basic Shiny dashboard.
Shiny includes most of the components that you'll need to build performant data dashboards
including:

- [Sidebar pages](https://shiny.posit.co/py/api/ui.layout_sidebar.html)
- [Value boxes](https://shiny.posit.co/py/api/ui.value_box.html)
- [Popovers](https://shiny.posit.co/py/api/ui.popover.html) and [tooltips](https://shiny.posit.co/py/api/ui.popover.html)
- [Accordions](https://shiny.posit.co/py/api/ui.accordion.html)
- [Modals](https://shiny.posit.co/py/api/ui.modal.html)
- [Cards](https://shiny.posit.co/py/api/ui.card.html)
