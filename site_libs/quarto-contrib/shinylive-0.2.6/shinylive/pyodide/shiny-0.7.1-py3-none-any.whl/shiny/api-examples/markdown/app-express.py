from shiny.express import ui

ui.markdown(
    """
    # Hello World

    This is **markdown** and here is some `code`:

    ```python
    print('Hello world!')
    ```
    """
)
