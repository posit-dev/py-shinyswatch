from ._data_frame import output_data_frame

__all__ = ("output_data_frame",)
